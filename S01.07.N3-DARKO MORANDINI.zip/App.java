import java.io.IOException;

public class App {

	public static void main(String[] args) {
        AnotacionPersonalizada obj = new AnotacionPersonalizada();

        try {
            // Serializar el objeto en JSON y guardarlo en el archivo correspondiente
            obj.serializeToJson();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    
        obj.mostrarSerializeToJsonAnnotation();
	}
}