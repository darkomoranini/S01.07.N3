import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
@interface SerializeToJson {
    String directory();
}

@SerializeToJson(directory = "/Users/darkomorandini/eclipse/ARCHIVOS EXT")
class AnotacionPersonalizada {
    
    public AnotacionPersonalizada() {
   
    }

    public void serializeToJson() throws IOException {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        String json = gson.toJson(this);

        String directory = getClass().getAnnotation(SerializeToJson.class).directory();
        String filePath = directory + "/" + getClass().getSimpleName() + ".json";

        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(json);
        }catch(IOException e) {
        	e.printStackTrace();
        }
    }

    public void mostrarSerializeToJsonAnnotation() {
        Class<?> annotatedClass = AnotacionPersonalizada.class;
        Annotation annotation = annotatedClass.getAnnotation(SerializeToJson.class);
        if (annotation != null) {
            SerializeToJson serializeToJson = (SerializeToJson) annotation;
            String directory = serializeToJson.directory();
            System.out.println("Anotacion SerializeToJson encontrada");
            System.out.println("Directory: " + directory);
        } else {
            System.out.println("SerializeToJson Annotation not found!");
        }
    }



}